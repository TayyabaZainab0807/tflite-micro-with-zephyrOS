#include <cstdint>

extern const unsigned int g_hello_world_model_data_size;
extern const unsigned char g_hello_world_model_data[];
