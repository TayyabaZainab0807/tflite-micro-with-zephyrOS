#ifndef _H_HANN_WINDOW_
#define _H_HANN_WINDOW_

#include <cmath>
#include <cstdio>

class HannWindow {
  int cnt = 0;
private:
    // c standard defind 
    //#define M_PI (3.14159265358979323846)::

    // MATLAB 'pi'
    const double MATLAB_pi= 3.141592653589793;
    float32_t *hann;
    int shift_size;
    int frame_size;


public:
    inline HannWindow(int _frame_size, int _shift_size);
    inline ~HannWindow();
    inline void Process(float32_t * buf);
};

inline HannWindow::HannWindow(int _frame_size, int _shift_size) {
    int i;
    float32_t tmp = 0;

    shift_size = _shift_size;
    frame_size = _frame_size;

    hann = new float32_t[frame_size];

    // win = hanning(frame_size,'periodic');
    for (i = 0; i < frame_size; i++)
      hann[i] = 0.5 * (1.0 - cos(2.0 * MATLAB_pi* (i / (float32_t)frame_size)));

    // win = win./sqrt(sum(win.^2)/shift_size);
    for (i = 0; i < frame_size; i++)
      tmp += hann[i] * hann[i];
    tmp /= shift_size;
    tmp = std::sqrt(tmp);

    for (i = 0; i < frame_size; i++)
      hann[i] /= tmp;

    
}

inline HannWindow::~HannWindow() { delete[] hann; }


inline void HannWindow::Process(float32_t *buffer){
    int j;
        for (j = 0; j < frame_size; j++) {
           buffer[j] *= hann[j];
        }
}

#endif
