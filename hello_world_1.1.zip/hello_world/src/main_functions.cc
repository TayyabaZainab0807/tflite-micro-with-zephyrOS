/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "tensorflow/lite/micro/examples/hello_world/main_functions.h"
#include <zephyr/zephyr.h>
#include "tensorflow/lite/micro/all_ops_resolver.h"
#include "constants.h"
#include "hello_world_model_data.h"
#include "tensorflow/lite/micro/examples/hello_world/output_handler.h"
#include "tensorflow/lite/micro/micro_error_reporter.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/system_setup.h"
#include "tensorflow/lite/schema/schema_generated.h"

#include "arm_math.h"
#include "arm_const_structs.h"

#include "cpp/STFT.h"
#include "FFTsignal.h"


// Globals, used for compatibility with Arduino-style sketches.
namespace {
tflite::ErrorReporter* error_reporter = nullptr;
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
TfLiteTensor* output = nullptr;
int inference_count = 0;

constexpr int kTensorArenaSize = 200000+16;
uint8_t tensor_arena[kTensorArenaSize];
 

}  // namespace

// The name of this function is important for Arduino compatibility.
void setup() {

  
  tflite::InitializeTarget();

  
  static tflite::MicroErrorReporter micro_error_reporter;
  error_reporter = &micro_error_reporter;

  model = tflite::GetModel(g_hello_world_model_data);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    TF_LITE_REPORT_ERROR(error_reporter,
                         "Model provided is schema version %d not equal "
                         "to supported version %d.",
                         model->version(), TFLITE_SCHEMA_VERSION);
    return;
  }
  
  static tflite::AllOpsResolver resolver;
  

  static tflite::MicroInterpreter static_interpreter(
      model, resolver, tensor_arena, kTensorArenaSize, error_reporter);
  interpreter = &static_interpreter;


  TfLiteStatus allocate_status = interpreter->AllocateTensors();
  if (allocate_status != kTfLiteOk) {
    printk("AllocateTensors() failed\n");
    return;
  }
  input = interpreter->input(0);
  output = interpreter->output(0);

  inference_count = 0;
}

#define FFT_SAMPLES 128
#define FFT_SAMPLES_HALF (FFT_SAMPLES / 2)

// see gist

static float32_t complexFFT[FFT_SAMPLES];

uint32_t fftSize = FFT_SAMPLES;
uint32_t ifftFlag = 0;
arm_rfft_fast_instance_f32 S;
arm_status status;
int i;

#define SLEEP_TIME_MS   100

// The name of this function is important for Arduino compatibility.
void loop() {

STFT process(1,FFT_SAMPLES,40);
       
       int64_t time_stamp;
       int64_t milliseconds_spent;

       time_stamp = k_uptime_get();
       for(int j=0;j<3;j++)
       for(int i=0;i<100;i++){
       process.stft(inputSignal,complexFFT);
    }

  milliseconds_spent = k_uptime_delta(&time_stamp);
	printk(  "Time exec = %lld",milliseconds_spent);

  k_msleep(3000);
  /*
    printk("hello");
    
   
    //milliseconds_spent = k_uptime_delta(&time_stamp);
    //printk(  "Time exec = %lld",milliseconds_spent);
    printk("here!\n");

    int64_t time_stamp;
	int64_t milliseconds_spent;

    for (int d = 0; d < 18573; ++d) {input->data.f[d] = 0;} //784
	  printk("Required memory %i bytes.\n", interpreter->arena_used_bytes());
	
    time_stamp = k_uptime_get();

		TfLiteStatus invoke_status = interpreter->Invoke();

		if (invoke_status != kTfLiteOk) {
			TF_LITE_REPORT_ERROR(error_reporter,
						"Invoke failed.");
		}

		milliseconds_spent = k_uptime_delta(&time_stamp);
		printk(  "Time exec = %lld",milliseconds_spent);

		 k_msleep(1000);
     */
		

  // Output the results. A custom HandleOutput function can be implemented
  // for each supported hardware target.

  // Increment the inference_counter, and reset it if we have reached
  // the total number per cycle

}