#ifndef _H_STFT_
#define _H_STFT_

#include "HannWindow.h"
#include "arm_math.h"
#include "arm_const_structs.h"

#define FFT_SAMPLES 128

class STFT{
  private : 
    const double MATLAB_scale = 32768;

    HannWindow *hw;

    int channels;
    int frame_size;
    int shift_size;
    int ol;
    uint32_t ifftFlag = 0;
    uint32_t fftSize = FFT_SAMPLES;
    arm_rfft_fast_instance_f32 S;
    arm_status status;
    
    float32_t**buf;

  public :
    inline STFT(int channels,int frame,int shift);
    //inline ~STFT();
    inline void stft(float32_t* in, float32_t* out);

};


STFT::STFT(int channels_,int frame_,int shift_){
  int i;
  channels = channels_;
  frame_size = frame_;
  shift_size = shift_;
  ol = frame_size - shift_size;

  status = ARM_MATH_SUCCESS;

  status = arm_rfft_fast_init_f32(&S, frame_size);

  hw = new HannWindow(frame_size, shift_size);

  buf =  new float32_t*[channels];
  for(i=0;i<channels;i++){
    buf[i] = new float32_t[frame_size];
    memset(buf[i],0,sizeof(float32_t)*frame_size);
  }
 
} 
/*
STFT::~STFT(){
  int i;
  delete hw;
  
  for(i=0;i<channels;i++)
    delete[] buf[i];
  delete[] buf;
}*/



// Single-Channel double
void STFT::stft(float32_t* inputSignal, float32_t* complexFFT){
  float32_t out[frame_size];
	int i;
    /*** Shfit & Copy***/
    for (i = 0; i < ol; i++) {
        buf[0][i] = buf[0][i + shift_size];
    }
    for (i = 0; i < shift_size; i++)
        buf[0][ol + i] = inputSignal[i];


    memcpy(out, buf[0], sizeof(float32_t) * frame_size);

    // scaling for precision
    for (int j = 0; j < frame_size; j++)
      out[j] /= MATLAB_scale;

    /*** Window ***/
    hw->Process(out);
    arm_rfft_fast_f32(&S, out, complexFFT, ifftFlag);
}

#endif
