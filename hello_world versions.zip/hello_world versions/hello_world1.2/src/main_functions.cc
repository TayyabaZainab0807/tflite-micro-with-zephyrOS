/* Copyright 2020 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "main_functions.h"
#include <zephyr/zephyr.h>
#include "constants.h"
#include "hello_world_model_data.h"
#include "output_handler.h"
#include "tensorflow/lite/micro/micro_interpreter.h"
#include "tensorflow/lite/micro/system_setup.h"
#include "tensorflow/lite/schema/schema_generated.h"
#include "tensorflow/lite/micro/micro_log.h"
#include "tensorflow/lite/micro/micro_mutable_op_resolver.h"




// Globals, used for compatibility with Arduino-style sketches.
namespace {
const tflite::Model* model = nullptr;
tflite::MicroInterpreter* interpreter = nullptr;
TfLiteTensor* input = nullptr;
TfLiteTensor* output = nullptr;


constexpr int kTensorArenaSize = 200000+16;
uint8_t tensor_arena[kTensorArenaSize];
 

}  // namespace

// The name of this function is important for Arduino compatibility.
void setup() {

  
  tflite::InitializeTarget();

  

  model = tflite::GetModel(g_hello_world_model_data);
  if (model->version() != TFLITE_SCHEMA_VERSION) {
    MicroPrintf("Model provided is schema version %d not equal "
                         "to supported version %d.",
                         model->version(), TFLITE_SCHEMA_VERSION);
    return;
  }
  
  static tflite::MicroMutableOpResolver<12> micro_op_resolver;
  if (micro_op_resolver.AddDequantize()!= kTfLiteOk) {
    return;
  }
  if(micro_op_resolver.AddQuantize()!= kTfLiteOk) {
    return;
  }
  if(micro_op_resolver.AddConv2D()!= kTfLiteOk) {
    return;
  }
  if(micro_op_resolver.AddMul()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddAdd()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddReshape()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddUnpack()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddFullyConnected()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddSplit()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddLogistic()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddTanh()!= kTfLiteOk) {
    return;
  }
  if (micro_op_resolver.AddPack()!= kTfLiteOk) {
    return;
  }
    
  // Build an interpreter to run the model with.
  // NOLINTNEXTLINE(runtime-global-variables)
  static tflite::MicroInterpreter static_interpreter(
      model, micro_op_resolver, tensor_arena, kTensorArenaSize);
  interpreter = &static_interpreter;

  // Allocate memory from the tensor_arena for the model's tensors.
  TfLiteStatus allocate_status = interpreter->AllocateTensors();
  if (allocate_status != kTfLiteOk) {
    MicroPrintf("AllocateTensors() failed");
    return;
  }

  printk("here2\n");
  input = interpreter->input(0);
  output = interpreter->output(0);

}



// The name of this function is important for Arduino compatibility.
void loop() {

    printk("here!!!\n");
    printk("Required memory %i bytes.\n", interpreter->arena_used_bytes());
    printf("size:           %d\n", input->dims->size);
    printf("data[0]:        %d\n", input->dims->data[0]);
    printf("kNumRows:       %d\n", input->dims->data[1]);
    printf("kNumCols:       %d\n", input->dims->data[2]);
    printf("kNumChannels:   %d\n", input->dims->data[3]);
    //for (int d = 0; d < 18573; ++d) {input->data.f[d] = 0;} //784
    printk("hello");
    
   
    //milliseconds_spent = k_uptime_delta(&time_stamp);
    //printk(  "Time exec = %lld",milliseconds_spent);
    printk("here!\n");

    int64_t time_stamp;
	  int64_t milliseconds_spent;

	  printk("Required memory %i bytes.\n", interpreter->arena_used_bytes());
	
    time_stamp = k_uptime_get();

    
		TfLiteStatus invoke_status = interpreter->Invoke();
		if (invoke_status != kTfLiteOk) {
			printk("Invoke failed.");
		}
		milliseconds_spent = k_uptime_delta(&time_stamp);
		printk(  "Time exec = %lld",milliseconds_spent);

		 k_msleep(1000);
   
}